/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.common.test.util;

import com.dbs.tonl.api.common.util.TestUtil;
import org.junit.Test;

/**
 * Test class for {@link com.dbs.tonl.api.common.util.TestUtil}.
 *
 * @author quirinogervacio on 12/1/15.
 */
public class TestUtilTest {

    /**
     * Test.
     */
    @Test(expected = NullPointerException.class)
    public void testNpe() {
        String string = null;
        TestUtil.test(NullPointerException.class, string != null, "Variable \"string\" must not be null");
    }
}