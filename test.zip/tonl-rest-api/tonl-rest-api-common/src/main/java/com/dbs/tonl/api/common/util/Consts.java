package com.dbs.tonl.api.common.util;

/**
 * Created by xueliang on 11/03/2015.
 */
public final class Consts {
    public static final int CIS_BY_CIN = 1;
    public static final int CIS_BY_ACC = 2;
}
