package com.dbs.tonl.api.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by xueliang on 15/01/2015.
 */
public class PerformanceLogger {

    private static final Logger logger = LoggerFactory.getLogger(PerformanceLogger.class);

    public static void logDuration(String callName, long startTime) {
        long duration = System.currentTimeMillis() - startTime;
        logger.info(callName + "," + duration + ",ms");
    }
}
