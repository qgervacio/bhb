/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.common.util;

/**
 * Test utilities methods.
 *
 * @author quirinogervacio on 12/1/15.
 */
public class TestUtil {

    /**
     * Execute a boolean test to check a certain expectation is met. If so, nothing will be thrown, otherwise the
     * provided exception class will be thrown with the provided exception message. If for some reason this method
     * failed during object construction, the stack trace will be printed and no exception will be thrown.
     *
     * @param exceptionClass   the exception class to throw if test yielded to false
     * @param trueTest         the test that is expected to be true
     * @param exceptionMessage the message to throw if test yielded to false. providing null will use whatever the exception
     *                         class already has
     * @param <E>              the exception type
     * @throws java.lang.NullPointerException if parameter exceptionClass is null
     * @throws E                              the exception that is intended to be thrown if <code>trueTest</code> failed
     */
    public static <E extends Throwable> void test(final Class<E> exceptionClass,
                                                  final boolean trueTest,
                                                  final String exceptionMessage) throws E {

        // basic test
        if (exceptionClass == null) {
            throw new NullPointerException("Parameter \"exceptionClass\" cannot be null");
        }

        // execute test first. don't bother creating objects if it is satisfied
        E e = null;
        if (!trueTest) {
            try {
                @SuppressWarnings("unchecked")
                E ex = exceptionMessage == null ? exceptionClass.newInstance() : (E) Class.forName(exceptionClass.getName())
                                                                                          .getConstructor(String.class)
                                                                                          .newInstance(exceptionMessage);
                e = ex;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (e != null) {
                throw e;
            }
        }
    }
}