/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.ErrorModel;
import com.dbs.tonl.api.web.interceptor.ErrorInterceptor;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Error controller.
 *
 * @author quirinogervacio on 9/1/15.
 */
@Controller
class ErrorController {

    @Autowired
    private ErrorInterceptor errorInterceptor;

    @ResponseBody
    @ExceptionHandler
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @RequestMapping(value = UriConstantConf.ERROR.ERR404,
                    method = RequestMethod.GET)
    private ErrorModel err404(final HttpServletRequest req, final HttpServletResponse res) {
        return this.errorInterceptor.handle(req, res, new Exception(HttpStatus.NOT_FOUND.getReasonPhrase()));
    }
}