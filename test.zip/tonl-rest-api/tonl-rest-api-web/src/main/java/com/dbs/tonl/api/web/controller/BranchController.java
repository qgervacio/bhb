/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.service.BranchService;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Branches controller.
 *
 * @author quirinogervacio on 12/1/15.
 */
@RestController
class BranchController {

    @Autowired
    private BranchService branchService;

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.BRANCHES_USERNAME_USERNAME_GROUP_GROUP,
                    method = RequestMethod.GET)
    private List<String> getBranchesFromUserInGroup(@PathVariable("username") final String username,
                                                    @PathVariable("group") final String rootGroup) {
        return this.branchService.getBranchesFromUserInGroup(username, rootGroup);
    }
}