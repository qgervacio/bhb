/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.setup.conf;

/**
 * Role constants configuration.
 *
 * @author quirinogervacio on 8/1/15.
 */
public final class RoleConstConf {
    static final        String USER       = "USER";
    public static final String ROLE_USER  = "ROLE_" + USER;
    static final        String ADMIN      = "ADMIN";
    public static final String ROLE_ADMIN = "ROLE_" + ADMIN;
}