/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.UserModel;
import com.dbs.tonl.api.core.service.UserService;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Rest controller for user related operations.
 *
 * @author quirinogervacio on 19/12/14.
 * @author quirinogervacio on 19/12/14.
 */
@RestController
class UserController {

    @Autowired
    private UserService userService;

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.USERS_USERNAME,
                    method = RequestMethod.GET)
    private UserModel getUser(@PathVariable final String username) {
        return this.userService.getUser(username);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.USERS_GROUP_GROUPNAME,
                    method = RequestMethod.GET)
    private List<UserModel> getUsersByGroupName(@PathVariable final String groupName) {
        return this.userService.getUsersByGroupName(groupName);
    }
}