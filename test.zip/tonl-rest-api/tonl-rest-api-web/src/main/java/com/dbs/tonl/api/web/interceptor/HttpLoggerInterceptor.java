/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.interceptor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * HTTP logger interceptor.
 *
 * @author quirinogervacio on 8/1/15.
 */
public class HttpLoggerInterceptor extends HandlerInterceptorAdapter {
    private static final Logger logger = LoggerFactory.getLogger(HttpLoggerInterceptor.class);

    @Override
    public void afterCompletion(final HttpServletRequest request,
                                final HttpServletResponse response,
                                final Object handler,
                                final Exception ex) throws Exception {
        String ipAddr = request.getHeader("X-FORWARDED-FOR");
        if(ipAddr == null)
        {
            ipAddr = request.getRemoteAddr();
        }
        logger.info(ipAddr + " " + request.getMethod() + " " + response.getStatus() + " " + request.getRequestURI() + "[" + StringUtils.stripToEmpty(
                request.getQueryString()) + "] ");
    }
}