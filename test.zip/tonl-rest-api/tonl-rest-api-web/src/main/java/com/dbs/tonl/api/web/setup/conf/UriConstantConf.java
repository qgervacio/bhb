/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.setup.conf;

/**
 * URI constants.
 *
 * @author quirinogervacio on 23/12/14.
 */
public final class UriConstantConf {

    // index
    public static final String INDEX = "/";

    // index
    public static final String ADMIN = "/admin";

    // rest
    public static final String REST = "/rest";

    // get the current version
    public static final String VERSION = REST + "/v";

    /**
     * Error URI. This is also set in web.xml
     *
     * @author quirinogervacio on 9/1/2015.
     */
    public static interface ERROR {
        public static final String ERR    = "/err";
        public static final String ERR404 = "/err404";
    }

    // version 1
    public static final class V1 {
        private static final String VERSION = REST + "/v1";

        // users
        public static final String USERS_USERNAME        = VERSION + "/users/{username}";
        public static final String USERS_GROUP_GROUPNAME = VERSION + "/users/group/{groupName}";

        // clients
        public static final String CLIENTS_SEARCH            = VERSION + "/clients";
        public static final String CLIENTS_SEARCH_CIS_CIN        = VERSION + "/clients/cis/cin/{cin}";
        public static final String CLIENTS_SEARCH_CIS_ACC        = VERSION + "/clients/cis/acc/{acc}";
        public static final String CLIENTS_CIN_CIN           = VERSION + "/clients/cin/{cin}";
        public static final String CLIENTS_NAME_NAME         = VERSION + "/clients/name/{name}";
        public static final String CLIENTS_MNEMONIC_MNEMONIC = VERSION + "/clients/mnemonic/{mnemonic}";
        public static final String CLIENTS_ACCOUNT_ACCOUNT   = VERSION + "/clients/account/{account}";

        public static final String NEWS   = VERSION + "/news";
        public static final String PCE_LIMIT   = VERSION + "/pcelimit";

        // branches
        // ex. rest/v1/branches/username/charistansm/group/DBSSG
        public static final String BRANCHES_USERNAME_USERNAME_GROUP_GROUP = VERSION + "/branches/username/{username}/group/{group}";
    }
}