/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * TODO. System architecture AOP.
 *
 * @author quirinogervacio on 7/1/15.
 */
@Aspect
public class SystemArchitectureAop {

    @Pointcut("within(com.dbs.tonl.api.web.controller..*)")
    public void webLayer() {
    }

    @Pointcut("within(com.dbs.tonl.api.core.service..*)")
    public void serviceLayer() {
    }

    @Pointcut("within(com.dbs.tonl.api.core.dao..*)")
    public void dataAccessLayer() {
    }
}