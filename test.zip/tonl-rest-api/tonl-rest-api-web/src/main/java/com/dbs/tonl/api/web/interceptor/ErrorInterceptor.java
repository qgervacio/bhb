/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.interceptor;

import com.dbs.tonl.api.core.model.ErrorModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Error interceptor.
 *
 * @author quirinogervacio on 7/1/15.
 */
@ControllerAdvice
public class ErrorInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(ErrorInterceptor.class);

    @ResponseBody
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorModel handle(final HttpServletRequest request, final HttpServletResponse response, final Exception ex) {
        logger.info(request.getMethod() + " " + response.getStatus() + " " + request.getRequestURI() + "[" + StringUtils.stripToEmpty(
                request.getQueryString()) + "]\n" + ExceptionUtils.getStackTrace(ex));
        ErrorModel errorModel = new ErrorModel();
        errorModel.setMessage(ex.getMessage());
        errorModel.setClazz(ex.getClass());
        return errorModel;
    }
}