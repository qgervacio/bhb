package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.NewsModel;
import com.dbs.tonl.api.core.service.NewsService;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
@RestController
public class NewsController {
    @Autowired
    private NewsService newsService;

    @ResponseBody
    @RequestMapping(value = UriConstantConf.V1.NEWS,
            method = RequestMethod.GET)
    private List<NewsModel> getNews(@RequestParam(value = "numOfNews", required = false, defaultValue = "10") final Integer numOfNews) {
        return this.newsService.getNews(numOfNews);
    }
}
