/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.setup.conf;

import com.dbs.tonl.api.core.conf.CoreConf;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * Application configuration.
 *
 * @author quirinogervacio on 6/1/15.
 */
@Configuration
@ComponentScan(basePackages = "com.dbs.tonl.api.*")
@Import(value = {WebConf.class, CoreConf.class, SecurityConf.class, AspectConf.class})
public class ApplicationConf {

    /**
     * Required for @PropertySources to work.
     *
     * @return the properties
     */
    @Bean
    protected static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}