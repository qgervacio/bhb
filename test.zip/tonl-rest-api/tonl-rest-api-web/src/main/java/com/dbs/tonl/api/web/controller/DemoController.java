/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Demo controller.
 *
 * @author quirinogervacio on 9/1/15.
 */
@RestController
class DemoController {

    @ResponseBody
    @RequestMapping(value = "/demoexu",
                    method = RequestMethod.GET)
    private void demoexu() {
        throw new NullPointerException("Value cannot be null");
    }

    @ResponseBody
    @RequestMapping(value = "/demoexc",
                    method = RequestMethod.GET)
    private void demoexc() throws Exception {
        throw new Exception("Checked exceptions are not advisable in controllers");
    }
}