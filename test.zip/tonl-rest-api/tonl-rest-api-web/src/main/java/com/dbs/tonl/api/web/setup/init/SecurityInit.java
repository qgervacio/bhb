/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.setup.init;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Security initializer.
 *
 * @author quirinogervacio on 7/1/15.
 */
public class SecurityInit extends AbstractSecurityWebApplicationInitializer {}