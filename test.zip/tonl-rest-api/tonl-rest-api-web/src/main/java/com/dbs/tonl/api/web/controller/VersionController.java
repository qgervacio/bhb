/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.VersionModel;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rest controller to allow user to get information regarding the API.
 *
 * @author quirinogervacio on 19/12/14.
 */
@RestController
@PropertySources(@PropertySource("classpath:app.properties"))
class VersionController {

    @Autowired
    private Environment env;

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.VERSION,
                    method = RequestMethod.GET)
    private VersionModel get() {
        VersionModel model = new VersionModel();
        model.setVersion(this.env.getProperty("rest.version.latest"));
        return model;
    }
}