/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Admin controller.
 *
 * @author quirinogervacio on 7/1/15.
 */
@Controller
class AdminController {

    @Secured(RoleConstConf.ROLE_ADMIN)
    @RequestMapping(value = UriConstantConf.ADMIN,
                    method = RequestMethod.GET)
    private ModelAndView index() {
        return new ModelAndView("admin");
    }
}