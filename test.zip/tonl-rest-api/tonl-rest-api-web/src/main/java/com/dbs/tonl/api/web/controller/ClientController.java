/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import com.dbs.tonl.api.core.service.CISOnlineService;
import com.dbs.tonl.api.core.service.ClientService;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.dbs.tonl.api.common.util.Consts;

import java.util.HashMap;

/**
 * Client controller.
 *
 * @author quirinogervacio on 12/1/15.
 */
@RestController
@PropertySources(@PropertySource("classpath:app.properties"))
class ClientController {

    @Autowired
    private Environment env;

    @Autowired
    private ClientService clientService;

    @Autowired
    private CISOnlineService cisOnlineService;

    private static final Logger logger = LoggerFactory.getLogger(ClientController.class);

    private ClientModel getCISClients(final int searchType, final String fullStr)
    {
        return this.cisOnlineService.getClients(searchType, fullStr);
    }

    private HashMap getClients(final String st,
                                         final String sv,
                                         final String mt,
                                         final String un,
                                         final Integer sr,
                                         final Integer nr) {
        ClientCriteriaModel model = new ClientCriteriaModel();

        // double check to remove invalid characters
        String searchValue = sv;
        searchValue = searchValue.replaceAll("[~\\\\/<>\\&%]", "");
        // escape wildcard
        searchValue = searchValue.replaceAll("_", "\\\\_");
        searchValue = searchValue.replaceAll("'", "''");
        searchValue = searchValue.replace("\"", "\\\"");
        searchValue = searchValue.replace("'", "");
        model.setSearchValue(searchValue);

        model.setSearchField(st);

        model.setMatchType(mt);
        model.setRETUserName(un);
        model.setStartRow(sr);
        model.setNumRow(nr);

        String rootGroup = env.getProperty("ret.sg.search.rootgroup");
        if(rootGroup != null && !rootGroup.isEmpty())
            model.setRootGroup(rootGroup);
        else {
            logger.error("ret.sg.search.rootgroup is missing, setting it to DBSSG now");
            model.setRootGroup("DBSSG");
        }
        return this.clientService.getClients(model);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.CLIENTS_CIN_CIN,
                    method = RequestMethod.GET)
    private HashMap getClientsByCin(@PathVariable final String cin,
                                              @RequestParam(value = "matchType", required = false, defaultValue = ClientCriteriaModel.MATCH_TYPE.CONTAINS)
                                              final String mt,
                                              @RequestParam(value = "salesID", required = true) final String un,
                                              @RequestParam(value = "startRow", required = false, defaultValue = "1") final Integer sr,
                                              @RequestParam(value = "numRows", required = false, defaultValue = "50") final Integer nr) {
        return this.getClients(ClientCriteriaModel.SEARCH_TYPE.CIN, cin, mt, un, sr, nr);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.CLIENTS_NAME_NAME,
                    method = RequestMethod.GET)
    private HashMap getClientsByName(@PathVariable final String name,
                                               @RequestParam(value = "matchType", required = false, defaultValue = ClientCriteriaModel.MATCH_TYPE.CONTAINS)
                                               final String mt,
                                               @RequestParam(value = "salesID", required = true) final String un,
                                               @RequestParam(value = "startRow", required = false, defaultValue = "1") final Integer sr,
                                               @RequestParam(value = "numRows", required = false, defaultValue = "50") final Integer nr) {
        return this.getClients(ClientCriteriaModel.SEARCH_TYPE.NAME, name, mt, un, sr, nr);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.CLIENTS_MNEMONIC_MNEMONIC,
                    method = RequestMethod.GET)
    private HashMap getClientsByMnemonic(@PathVariable final String mnemonic,
                                                   @RequestParam(value = "matchType", required = false,
                                                                 defaultValue = ClientCriteriaModel.MATCH_TYPE.CONTAINS)
                                                   final String mt,
                                                   @RequestParam(value = "salesID", required = true) final String un,
                                                   @RequestParam(value = "startRow", required = false, defaultValue = "1") final Integer sr,
                                                   @RequestParam(value = "numRows", required = false, defaultValue = "50") final Integer nr) {
        return this.getClients(ClientCriteriaModel.SEARCH_TYPE.MNEMONIC, mnemonic, mt, un, sr, nr);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.CLIENTS_ACCOUNT_ACCOUNT,
                    method = RequestMethod.GET)
    private HashMap getClientsByAccount(@PathVariable final String account,
                                                  @RequestParam(value = "matchType", required = false,
                                                                defaultValue = ClientCriteriaModel.MATCH_TYPE.CONTAINS)
                                                  final String mt,
                                                  @RequestParam(value = "salesID", required = true) final String un,
                                                  @RequestParam(value = "startRow", required = false, defaultValue = "1") final Integer sr,
                                                  @RequestParam(value = "numRows", required = false, defaultValue = "50") final Integer nr) {
        return this.getClients(ClientCriteriaModel.SEARCH_TYPE.ACCOUNT, account, mt, un, sr, nr);
    }

    @ResponseBody
    @RequestMapping(value=UriConstantConf.V1.CLIENTS_SEARCH_CIS_CIN,
                    method = RequestMethod.GET)
    private ClientModel getClientsCISByCIN(@PathVariable final String cin)
    {
        return this.getCISClients(Consts.CIS_BY_CIN, cin);
    }

    @ResponseBody
    @RequestMapping(value=UriConstantConf.V1.CLIENTS_SEARCH_CIS_ACC,
            method = RequestMethod.GET)
    private ClientModel getClientsCISByACC(@PathVariable final String acc)
    {
        return this.getCISClients(Consts.CIS_BY_ACC, acc);
    }

    @ResponseBody
    @Secured(RoleConstConf.ROLE_USER)
    @RequestMapping(value = UriConstantConf.V1.CLIENTS_SEARCH,
            method = RequestMethod.GET)
    private HashMap getClientsGeneric(
                                                  @RequestParam(value = "matchType", required = false,
                                                          defaultValue = ClientCriteriaModel.MATCH_TYPE.CONTAINS)
                                                  final String matchType,
                                                  @RequestParam(value = "searchField",required = true) final String searchField,
                                                  @RequestParam(value = "searchValue",required = true) final String searchValue,
                                                  @RequestParam(value = "salesID", required = true) final String salesID,
                                                  @RequestParam(value = "startRow", required = false, defaultValue = "1") final Integer startRow,
                                                  @RequestParam(value = "numRows", required = false, defaultValue = "50") Integer numRows) {
        //
        return this.getClients(searchField, searchValue, matchType, salesID, startRow, numRows);
    }
}