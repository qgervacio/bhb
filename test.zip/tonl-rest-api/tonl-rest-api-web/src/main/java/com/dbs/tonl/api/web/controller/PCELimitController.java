package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.core.model.PCELimitModel;
import com.dbs.tonl.api.core.service.PCELimitService;
import com.dbs.tonl.api.web.setup.conf.RoleConstConf;
import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
@RestController
public class PCELimitController {

    @Autowired
    private PCELimitService pceLimitService;;

    @ResponseBody
    @RequestMapping(value = UriConstantConf.V1.PCE_LIMIT,
            method = RequestMethod.GET)
    private List<PCELimitModel> previewLimit(
            @RequestParam(value = "cin", required = true) final String cin,
            @RequestParam(value = "acc", required = false, defaultValue = "") final String account)
    {

        return this.pceLimitService.previewPCELimit(cin, account);
    }

}
