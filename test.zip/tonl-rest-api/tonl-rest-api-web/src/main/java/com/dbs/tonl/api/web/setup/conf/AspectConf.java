/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.setup.conf;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Aspect configuration.
 *
 * @author quirinogervacio on 7/1/15.
 */
@Configuration
@EnableAspectJAutoProxy
class AspectConf {}