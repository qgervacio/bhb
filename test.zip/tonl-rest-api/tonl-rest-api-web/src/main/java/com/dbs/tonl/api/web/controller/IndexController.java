/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.web.controller;

import com.dbs.tonl.api.web.setup.conf.UriConstantConf;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

/**
 * Index controller.
 *
 * @author quirinogervacio on 7/1/15.
 */
@Controller
class IndexController {

    @RequestMapping(value = UriConstantConf.INDEX,
                    method = RequestMethod.GET)
    private ModelAndView index() throws IOException {
        return new ModelAndView("index");
    }
}