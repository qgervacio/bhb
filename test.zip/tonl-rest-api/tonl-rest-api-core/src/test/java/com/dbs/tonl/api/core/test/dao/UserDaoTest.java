package com.dbs.tonl.api.core.test.dao;

import com.dbs.tonl.api.core.model.UserModel;
import com.dbs.tonl.api.core.service.UserService;
import com.dbs.tonl.api.core.test.AbstractTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * TODO
 *
 * @author quirinogervacio on tonl-rest-api, 2:01 PM - 16/01/2015
 * @since 0.0.1
 */
public class UserDaoTest extends AbstractTest {

    @Autowired
    private UserService userService;

    @Test
    public void getUserTest() {
        // get. it is expected that this user exists in database
        UserModel user = this.userService.getUser("ACOM");
        Assert.assertNotNull(user);
        Assert.assertEquals(user.getUsername(), "ACOM");
    }

    @Test
    public void getUsersByGroupNameTest() {
        // get. it is expected that this group has more than one user in database
        List<UserModel> users = this.userService.getUsersByGroupName("ABOUND_SHIP_CHARTERING_PTE_LTD");
        Assert.assertNotNull(users);
        Assert.assertTrue(users.size() > 0);
    }
}