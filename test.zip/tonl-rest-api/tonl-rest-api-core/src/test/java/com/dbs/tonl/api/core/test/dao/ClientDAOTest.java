package com.dbs.tonl.api.core.test.dao;

import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.dao.FindException;
import com.dbs.tonl.api.core.dao.InvalidParameterException;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import com.dbs.tonl.api.core.service.ClientService;
import com.dbs.tonl.api.core.test.AbstractTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.HashMap;

/**
 * Created by xueliang on 16/01/2015.
 */
public class ClientDAOTest extends AbstractTest {

    @Autowired
    @Qualifier("clientDaoImpl")
    private ClientDao clientDao;

    @Test
    public void getClientTestPositive() throws InvalidParameterException, FindException {
        ClientCriteriaModel testModel = new ClientCriteriaModel();
        testModel.setRETUserName("charistansm");
        testModel.setRootGroup("DBSSG");
        testModel.setNumRow(100);
        testModel.setStartRow(1);
        testModel.setMatchType("1");
        testModel.setSearchField("1");
        testModel.setSearchValue("abc");
        HashMap response = this.clientDao.getClients(testModel);
        Assert.assertTrue((Integer) response.get("TOTAL_RECORD") > 0);
    }

    @Test(expected = InvalidParameterException.class)
    public void getClientTestNegative() throws InvalidParameterException, FindException {
        ClientCriteriaModel testModel = new ClientCriteriaModel();
        testModel.setRETUserName("xxx");
        testModel.setRootGroup("DBSSG");
        testModel.setNumRow(100);
        testModel.setStartRow(1);
        testModel.setMatchType("1");
        testModel.setSearchField("1");
        testModel.setSearchValue("abc");
        HashMap<String, Object> response = this.clientDao.getClients(testModel);
    }
}
