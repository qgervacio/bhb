package com.dbs.tonl.api.core.test.dao;

import com.dbs.tonl.api.core.dao.NewsDao;
import com.dbs.tonl.api.core.model.NewsModel;
import com.dbs.tonl.api.core.service.NewsService;
import com.dbs.tonl.api.core.test.AbstractTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
public class NewsDaoTest extends AbstractTest {
    @Autowired
    private NewsService newsService;

    @Test
    public void getNewsTest()
    {
        List<NewsModel> testNews = this.newsService.getNews(1);
        Assert.assertNotNull(testNews);
        Assert.assertTrue(testNews.size() > 0);

    }
}
