package com.dbs.tonl.api.core.test;

import com.dbs.tonl.api.core.conf.CoreConf;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * TODO
 *
 * @author quirinogervacio on tonl-rest-api, 2:01 PM - 16/01/2015
 * @since 0.0.1
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CoreConf.class)
public abstract class AbstractTest {}