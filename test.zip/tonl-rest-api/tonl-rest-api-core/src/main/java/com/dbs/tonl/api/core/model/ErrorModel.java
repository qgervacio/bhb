/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Error model.
 *
 * @author quirinogervacio on 9/1/15.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ErrorModel extends AbstractModel {
    private String                     message;
    private Class<? extends Throwable> clazz;

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public Class<? extends Throwable> getClazz() {
        return clazz;
    }

    public void setClazz(final Class<? extends Throwable> clazz) {
        this.clazz = clazz;
    }
}