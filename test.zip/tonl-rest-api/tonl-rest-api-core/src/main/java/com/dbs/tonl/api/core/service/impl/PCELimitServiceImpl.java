package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.PCELimitDao;
import com.dbs.tonl.api.core.model.PCELimitModel;
import com.dbs.tonl.api.core.service.PCELimitService;
import com.dbs.tonl.api.core.service.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xueliang on 18/05/2015.
 */
@Service
public class PCELimitServiceImpl implements PCELimitService{
    @Autowired
    private PCELimitDao pceLimitDao;

    @Override
    public List<PCELimitModel> previewPCELimit(final String cin, final String account) throws ServiceException
    {
        try {
            return this.pceLimitDao.previewPCELimit(cin, account);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }

}
