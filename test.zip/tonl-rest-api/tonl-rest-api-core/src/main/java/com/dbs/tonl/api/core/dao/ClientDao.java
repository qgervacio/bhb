/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao;

import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.springframework.stereotype.Repository;

import java.util.HashMap;

/**
 * Client DAO.
 *
 * @author quirinogervacio on 9/1/15.
 */
@Repository
public interface ClientDao {

    public HashMap getClients(final ClientCriteriaModel clientCriteriaModel) throws FindException, InvalidParameterException;
}