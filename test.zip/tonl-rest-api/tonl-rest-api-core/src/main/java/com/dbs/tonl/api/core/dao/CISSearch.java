package com.dbs.tonl.api.core.dao;

import org.springframework.stereotype.Component;

/**
 * Created by xueliang on 12/03/2015.
 */
@Component
public interface CISSearch {

    public String acctHolderDetlInq(String account);

    public String custProfInq(String CIN);
}
