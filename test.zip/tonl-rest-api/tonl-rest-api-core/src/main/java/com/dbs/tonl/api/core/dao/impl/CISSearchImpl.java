package com.dbs.tonl.api.core.dao.impl;

/**
 * Created by xueliang on 11/03/2015.
 */
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import javax.jms.JMSException;

import com.dbs.tonl.api.core.dao.CISSearch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CISSearchImpl implements CISSearch {

    public static int count = 0;
    String reqMsg;
    String resMsg;
    String curDate = null;
    static Logger logger = LoggerFactory.getLogger(CISSearchImpl.class);

    public String acctHolderDetlInq(String account) {
        try {
            account = account.trim();
            logger.info("Searching ACCOUNT: " + account);

            curDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
                    .format(System.currentTimeMillis());
            curDate = curDate.replace(" ", "T");
            curDate = curDate.concat("+08:00");

            String reqMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Header>"
                    + "<EMSDetail xmlns=\"http://schemas.dbs.com/icc/ems\"><MsgVersion>3.0</MsgVersion><MsgUID>"
                    + account
                    + System.currentTimeMillis()
                    + "</MsgUID><SvcVersion>3.0</SvcVersion></EMSDetail><Trace xmlns=\"http://schemas.dbs.com/icc/ems\"><RqDateTime>"
                    + curDate
                    + "</RqDateTime><RqClient><RqClientId>RET</RqClientId><RqClientOrg>0001</RqClientOrg><RqClientCtry>SG</RqClientCtry>"
                    + "</RqClient><Operator><OpInternalId/><OpLoginId>TRSVDOL1</OpLoginId><OpRole>SYSTEM</OpRole></Operator></Trace></soapenv:Header>"
                    + "<soapenv:Body><acc:AcctHolderDetlInq xmlns:acc=\"http://schemas.dbs.com/icc/AcctProfSvc\"><ems:CommonRq xmlns:ems=\"http://schemas.dbs.com/icc/ems\">"
                    + "<ems:OrgCode>0001</ems:OrgCode><ems:ChannelId>00</ems:ChannelId><ems:RqSysRef>RET</ems:RqSysRef></ems:CommonRq>"
                    + "<acc:InqAcctId><acc:ExtAcctId>"
                    + account
                    + "</acc:ExtAcctId></acc:InqAcctId></acc:AcctHolderDetlInq></soapenv:Body></soapenv:Envelope>";

            resMsg = null;
            resMsg = MQHandler.getInstance().sendAndReceive(reqMsg, 6000);
        } catch (JMSException e) {
            logger.error("MQ error ", e);
            return "FAIL";
        } catch (Exception e) {
            logger.error("Exception ", e);
            return "FAIL";
        }

        return resMsg;
    }

    public String custProfInq(String CIN) {

        try {
            CIN = CIN.trim();
            logger.info("Searching CIN: " + CIN);

            curDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
                    .format(System.currentTimeMillis());
            curDate = curDate.replace(" ", "T");
            curDate = curDate.concat("+08:00");

            String reqCustProfInqMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Header><EMSDetail xmlns=\"http://schemas.dbs.com/icc/ems\"><MsgVersion>3.0</MsgVersion><MsgUID>{0}"
                    + System.currentTimeMillis()
                    + "</MsgUID><SvcVersion>3.0</SvcVersion></EMSDetail><Trace xmlns=\"http://schemas.dbs.com/icc/ems\"><RqDateTime>"
                    + curDate
                    + "</RqDateTime><RqClient><RqClientId>RET</RqClientId><RqClientOrg>0001</RqClientOrg><RqClientCtry>SGP</RqClientCtry></RqClient>"
                    + "<Operator><OpLoginId>TRSVDOL1</OpLoginId><OpRole>SYSTEM</OpRole></Operator></Trace></soapenv:Header><soapenv:Body>"
                    + "<cus:CustProfInq xmlns:cus=\"http://schemas.dbs.com/icc/CustomerSvc\"><ems:CommonRq xmlns:ems=\"http://schemas.dbs.com/icc/ems\">"
                    + "<ems:OrgCode>0001</ems:OrgCode><ems:ChannelId>00</ems:ChannelId><ems:RqSysRef>RET</ems:RqSysRef>"
                    + "</ems:CommonRq><ems:CISInternalId xmlns:ems=\"http://schemas.dbs.com/icc/ems\"><ems:CISCIN>{1}</ems:CISCIN>"
                    + "<ems:CISCINsfx>{2}</ems:CISCINsfx></ems:CISInternalId></cus:CustProfInq></soapenv:Body></soapenv:Envelope>";
            String cins[] = CIN.split("-");
            reqMsg = MessageFormat.format(reqCustProfInqMsg, cins[0], cins[0],
                    cins.length > 1 ? cins[1] : "00");

            resMsg = null;
            resMsg = MQHandler.getInstance().sendAndReceive(reqMsg, 6000);
        } catch (JMSException e) {
            logger.error("MQ error ", e);
            return "FAIL";
        } catch (Exception e) {
            logger.error("Exception ", e);
            return "FAIL";
        }

        return resMsg;
    }
}
