package com.dbs.tonl.api.core.conf;

import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * TODO
 *
 * @author quirinogervacio on tonl-rest-api, 1:43 PM - 16/01/2015
 * @since 0.0.1
 */
@Configuration
@ComponentScan(basePackages = "com.dbs.tonl.api.core")
@PropertySources(@PropertySource("classpath:app.properties"))
@Import(value = {CoreDbRepositoryConf.class})
public class CoreConf {

    /**
     * Required for @PropertySources to work.
     *
     * @return the properties
     */
    @Bean
    protected static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}