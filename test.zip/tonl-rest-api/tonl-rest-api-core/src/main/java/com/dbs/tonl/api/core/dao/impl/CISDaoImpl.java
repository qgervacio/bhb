package com.dbs.tonl.api.core.dao.impl;

import javax.xml.parsers.*;

import com.dbs.tonl.api.core.dao.CISSearch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.dbs.tonl.api.core.dao.CISDao;
import com.dbs.tonl.api.core.model.ClientModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dbs.tonl.api.common.util.Consts;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

/**
 * Created by xueliang on 11/03/2015.
 */
@Component
public class CISDaoImpl implements CISDao {
    private static final Logger logger = LoggerFactory.getLogger(CISDaoImpl.class);

    @Autowired
    private CISSearch cisOnlineSearch;

    public ClientModel getClients(final int CinORAcc, final String keyword)
    {
        ClientModel cm = null;
        switch(CinORAcc) {
            case Consts.CIS_BY_ACC:
                cm = searchByAccount(keyword);
                break;
            case Consts.CIS_BY_CIN:
                cm = searchByCIN(keyword);
                break;
            default:
                logger.error("Unrecognized search option: " + CinORAcc);
                return null;
        }
        return cm;
    }

    public ClientModel searchByAccount(String account) {

        DocumentBuilderFactory docF = null;
        DocumentBuilder docB = null;
        Document xmlDoc = null;

        String CIN = null;
        String resMsg = null;
        String status = null;
        String errMsg = null;
        resMsg = this.cisOnlineSearch.acctHolderDetlInq(account);
        if ("FAIL".equals(resMsg)) {
            logger.error("FAIL");
            logger.error("Error in processing the request, please contact support team");
            return null;
        } else {
            docF = DocumentBuilderFactory.newInstance();
            try {
                docB = docF.newDocumentBuilder();
                xmlDoc = docB.parse(new InputSource(
                        new StringReader(resMsg)));
            } catch (ParserConfigurationException | SAXException | IOException e) {
                logger.error("Error parsing response message");
            }
        }

        logger.info("AcctHolderDetlInq response msg is parsed successfully");

        // If returned msg is error
        if (xmlDoc.getElementsByTagName("faultstring").item(0) != null) {
            status = "FAIL";
            errMsg = xmlDoc.getElementsByTagName("faultstring").item(0)
                    .getFirstChild().getNodeValue();
            logger.error(status);
            logger.error(errMsg);
            return null;
        } // If account is not active
        else if (!"01".equals(xmlDoc
                .getElementsByTagName("ems:AcctStatus").item(0)
                .getFirstChild().getNodeValue())) {
            logger.error("FAIL");
            logger.error("Specified customer account is not active");
            return null;
        } else { // Retrieve CIN from returned message
            Element CINFromAccountNode = (Element) xmlDoc
                    .getElementsByTagName("ems:CISCIN").item(0);
            String CINFromAccount = CINFromAccountNode.getFirstChild()
                    .getNodeValue();
            Element CINSfxNode = (Element) xmlDoc.getElementsByTagName(
                    "ems:CISCINsfx").item(0);
            String CINSfx = CINSfxNode.getFirstChild().getNodeValue();
            CIN = CINFromAccount + "-" + CINSfx;
        }

        //perform search by CIN
        return searchByCIN(CIN);
    }


    public ClientModel searchByCIN(String CIN, List<String> branchList)
    {
        ClientModel clientModel = searchByCIN(CIN);
        boolean found = false;
        if(clientModel.getBranch() != null)
        {
            for(String branch : branchList)
            {
                if(branch.trim().equals(clientModel.getBranch().trim()))
                {
                    found = true;
                    return clientModel;
                }
            }
            logger.info("User does not have access to customer searched");
        }
        return null;

    }

    private ClientModel searchByCIN(String CIN)
    {
        ClientModel clientModel = new ClientModel();
        DocumentBuilderFactory docF = null;
        DocumentBuilder docB = null;
        Document xmlDoc = null;
        String resMsg = null;
        String status = null;
        String errMsg = null;
        String CINRec = null;
        String custNameRec = null;
        String branchRec = null;

        logger.info("Searching Customer by CIN: " + CIN);
        resMsg = this.cisOnlineSearch.custProfInq(CIN);
        if ("FAIL".equals(resMsg)) {
            logger.error("FAIL");
            logger.error("Error in processing the request, please contact support team");
            return null;
        } else {
            xmlDoc = null;
            docF = DocumentBuilderFactory.newInstance();
            try {
                docB = docF.newDocumentBuilder();
                xmlDoc = docB.parse(new InputSource(new StringReader(resMsg)));
            } catch (ParserConfigurationException | SAXException | IOException e) {
                logger.error("Unable to parse response message");
                return null;
            }
        }

        logger.info("custProfInq response msg is parsed successfully");
        // If return msg is error
        if (xmlDoc.getElementsByTagName("faultstring").item(0) != null) {
            status = "FAIL";
            errMsg = xmlDoc.getElementsByTagName("faultstring").item(0)
                    .getFirstChild().getNodeValue();
        } else {
            logger.info("Valid Customer Record Found!");
            // Retrieve value from returned message
            Element CINNode = (Element) xmlDoc.getElementsByTagName(
                    "ems:CISCIN").item(0);
            Element CINsfxNode = (Element) xmlDoc.getElementsByTagName(
                    "ems:CISCINsfx").item(0);
            CINRec = CINNode.getFirstChild().getNodeValue() + "-"
                    + CINsfxNode.getFirstChild().getNodeValue();
            Element custOwnerNode = (Element) xmlDoc.getElementsByTagName(
                    "op:CustOwner").item(0);
            int custOwnerRec = Integer.parseInt(custOwnerNode
                    .getFirstChild().getNodeValue());
            custNameRec = xmlDoc.getElementsByTagName("ems:FullName")
                    .item(0).getFirstChild().getNodeValue();
            switch (custOwnerRec) {
                case 0001:
                    branchRec = "SG_PB";
                    break;
                case 0002:
                    branchRec = "SG_PRIORITY";
                    break;
                case 0003:
                    branchRec = "SG_PVBK";
                    break;
                case 0004:
                    branchRec = "SG_EB";
                    break;
                case 0005:
                    branchRec = "SG_CORP";
                    break;
                case 0006:
                    branchRec = "SG_FIG";
                    break;
                case 0007:
                    branchRec = "SG_TREASURY";
                    break;
                default:
                    branchRec = "";
                    logger.info("Customer Owner Value is " + custOwnerRec);
                    break;
            }

            // Check If the user has access to the branchTier received
            //important: to be added in branch list validation
            //if (branchRec != "" && reqParams.getProperty(branchRec) != null) {
            if (branchRec != "") {
                status = "SUCCESS";
                logger.info("Client Name = " + custNameRec + ", CIN = " + CINRec + ", Branch = " + branchRec);
                clientModel.setBranch(branchRec);
                clientModel.setCin(CINRec);
                clientModel.setClientName(custNameRec);
            }
        }
        //only if valid client is found, code will reach here with a non-NULL ClientModel
        return clientModel;
    }

}
