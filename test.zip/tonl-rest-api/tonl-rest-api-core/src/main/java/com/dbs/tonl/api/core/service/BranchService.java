/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.service;

import com.dbs.tonl.api.core.dao.BranchDao;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Branch service.
 *
 * @author quirinogervacio on 12/1/15.
 */
@Service
public interface BranchService extends BranchDao {

    @Override
    public List<String> getBranchesFromUserInGroup(final String username, final String rootGroup) throws ServiceException;
}