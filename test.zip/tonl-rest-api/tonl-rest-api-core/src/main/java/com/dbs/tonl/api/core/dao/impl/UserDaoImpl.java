/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao.impl;

import com.dbs.tonl.api.core.dao.FindException;
import com.dbs.tonl.api.core.dao.UserDao;
import com.dbs.tonl.api.core.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User DAO implementation.
 *
 * @author quirinogervacio on 26/12/14.
 */
@Repository
class UserDaoImpl implements UserDao {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public UserModel getUser(final String username) throws FindException {
        try {
            String sql = "" +
                    "SELECT\n" +
                    "   FULLNAME  AS \"fullName\"\n" +
                    " , GROUPNAME AS \"groupName\"\n" +
                    " , LOGID     AS \"logId\"\n" +
                    " , ROLE      AS \"role\"\n" +
                    " , USERNAME  AS \"username\"\n" +
                    "FROM\n" +
                    "   USERS\n" +
                    "WHERE USERNAME = :username";

            // return. it is guaranteed that this query will return a single user
            MapSqlParameterSource namedParams = new MapSqlParameterSource();
            namedParams.addValue("username", username);
            return this.namedParameterJdbcTemplate.queryForObject(sql, namedParams, new BeanPropertyRowMapper<UserModel>(UserModel.class));
        } catch (Exception ex) {
            throw new FindException(ex);
        }
    }

    @Override
    public List<UserModel> getUsersByGroupName(final String groupName) throws FindException {
        try {
            String sql = "" +
                    "SELECT\n" +
                    "   FULLNAME  AS \"fullName\"\n" +
                    " , GROUPNAME AS \"groupName\"\n" +
                    " , LOGID     AS \"logId\"\n" +
                    " , ROLE      AS \"role\"\n" +
                    " , USERNAME  AS \"username\"\n" +
                    "FROM\n" +
                    "   USERS\n" +
                    "WHERE REGEXP_LIKE (GROUPNAME, \'^*" + groupName + "*$\', \'i\')";

            // return
            return this.namedParameterJdbcTemplate.query(sql, new BeanPropertyRowMapper<UserModel>(UserModel.class));
        } catch (Exception ex) {
            throw new FindException(ex);
        }
    }
}