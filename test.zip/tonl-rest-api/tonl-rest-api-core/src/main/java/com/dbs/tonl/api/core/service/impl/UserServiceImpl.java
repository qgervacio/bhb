/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.UserDao;
import com.dbs.tonl.api.core.model.UserModel;
import com.dbs.tonl.api.core.service.ServiceException;
import com.dbs.tonl.api.core.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * User service implementation.
 *
 * @author by quirinogervacio on 6/1/15.
 */
@Service
class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public UserModel getUser(final String username) throws ServiceException {
        try {
            return this.userDao.getUser(username);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public List<UserModel> getUsersByGroupName(final String groupName) throws ServiceException {
        try {
            return this.userDao.getUsersByGroupName(groupName);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
}