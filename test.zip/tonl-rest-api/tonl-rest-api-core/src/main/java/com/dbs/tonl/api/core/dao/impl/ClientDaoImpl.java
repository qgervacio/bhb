/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao.impl;

import com.dbs.tonl.api.common.util.Consts;
import com.dbs.tonl.api.common.util.PerformanceLogger;
import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.dao.FindException;
import com.dbs.tonl.api.core.dao.InvalidParameterException;
import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * Client DAO implementation.
 *
 * @author quirinogervacio on 9/1/15.
 */
@Repository
class ClientDaoImpl implements ClientDao {

    private static final Logger logger = LoggerFactory.getLogger(ClientDaoImpl.class);

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private BranchDaoImpl branchDaoImpl;

    @Autowired
    private CISDaoImpl cisDaoImpl;

    // used for parameter validation
    private final String[] MAGIC_NUMBER = {"0", "1", "2", "3"};

    //validate if parameters are with expected value
    private void validateClientSearchRequestParameters(ClientCriteriaModel clientCriteriaModel) throws FindException, InvalidParameterException {

        String matchType = clientCriteriaModel.getMatchType();
        String searchField = clientCriteriaModel.getSearchField();
        String searchValue = clientCriteriaModel.getSearchValue();
        String salesID = clientCriteriaModel.getRETUserName();
        int startRow = clientCriteriaModel.getStartRow();
        int numRows = clientCriteriaModel.getNumRow();

        logger.info("validateClientSearchRequestParameters: "  + "matchType = " + matchType
                + ", " + "searchType = " + searchField + ", " + "searchStr = " + searchValue + ", " + "salesID = " + salesID + ", "
                + "startRow = " + startRow + ", " + "numRows = " + numRows);


        if(!Arrays.asList(MAGIC_NUMBER).contains(matchType))
            throw new InvalidParameterException("Incorrect matchType: " + matchType);
        if(!Arrays.asList(MAGIC_NUMBER).contains(searchField))
            throw new InvalidParameterException("Incorrect searchField: " + searchField);
        if(startRow <= 0)
            throw new InvalidParameterException("startRow: " + startRow + "  shall be larger than or equal to 1");
        if(numRows <= 0)
            throw new InvalidParameterException("numRows: " + numRows + "  shall be a positive integer less than 100");

        try {
            if (!branchDaoImpl.validateRETUser(salesID))
                throw new InvalidParameterException("Unable to locate RET user: " + salesID);
        }
        catch(FindException ex)
        {
            throw ex;
        }

        //max no.of.records to be returned in 1 shot is: 100
        if(numRows > 100)
            clientCriteriaModel.setNumRow(100);


    }

    private HashMap initResponseData()
    {
        HashMap responseData = new HashMap();
        List<ClientModel> resultList = new ArrayList<ClientModel>(0);
        responseData.put("TOTAL_RECORD", 0);
        responseData.put("NO_OF_RECORD", 0);
        responseData.put("DATA", resultList);
        return responseData;
    }

    @Override
    public HashMap getClients(final ClientCriteriaModel clientCriteriaModel) throws FindException, InvalidParameterException {

        validateClientSearchRequestParameters(clientCriteriaModel);
        HashMap responseData = initResponseData();
        String searchField = clientCriteriaModel.getSearchField();
        String keyStr = clientCriteriaModel.getSearchValue();

        responseData.put("START_ROW", clientCriteriaModel.getStartRow());

        try {
            // get branches based on username. throw exception if non is found
            List<String> branches = this.branchDaoImpl.getBranchesFromUserInGroup(clientCriteriaModel.getRETUserName(),
                                                                                  clientCriteriaModel.getRootGroup());
            if (branches == null || branches.isEmpty()) {

                throw new FindException("No branch list for RET user: " + clientCriteriaModel.getRETUserName());
            }
            logger.info("Branch list for " + clientCriteriaModel.getRETUserName() + " : " + branches.toString());
            // build sql
            String[] sqlClauses = this.buildSQLWhereClause(clientCriteriaModel.getSearchField(),
                                                           this.buildSearchStrPattern(clientCriteriaModel.getSearchValue(),
                                                                                      clientCriteriaModel.getMatchType()),
                                                           this.buildTierFilterString(branches));

            String sql2count = this.buildCountStatement(sqlClauses[0]);
            logger.info("SQL count: " + sql2count);

            /*
            * 1. Peform DB search
            * 2. if found, return the result;
            * 3. if not found, perform CIS search
            * */
            int numOfRecordFetched = 0;


            String sql = this.buildSql(sqlClauses[0],
                    sqlClauses[1],
                    clientCriteriaModel.getStartRow(),
                    clientCriteriaModel.getNumRow(), clientCriteriaModel.getSearchField());
            logger.debug("Search SQL: " + sql);
            long startTime = System.currentTimeMillis();
            List<ClientModel> resultList = this.namedParameterJdbcTemplate.query(sql, new BeanPropertyRowMapper<ClientModel>(ClientModel.class));
            PerformanceLogger.logDuration("clientSearch - SQL search statement takes ", startTime);

            numOfRecordFetched = resultList.size();
            responseData.put("NO_OF_RECORD", resultList.size());
            responseData.put("DATA", resultList);
            if(numOfRecordFetched > 0) {
                if (numOfRecordFetched < clientCriteriaModel.getNumRow()) {
                    logger.info("All matched records are fetched, no need to do count statement query.");
                    responseData.put("TOTAL_RECORD", numOfRecordFetched);
                } else {
                    logger.info("Performing an estimated total count.");
                    //perform count statement
                    startTime = System.currentTimeMillis();
                    int totalRecords = this.jdbcTemplate.queryForObject(sql2count, Integer.class);
                    PerformanceLogger.logDuration("clientSearch - SQL count statement takes ", startTime);
                    responseData.put("TOTAL_RECORD", totalRecords);
                }
            }
            /*
            * If fetched nothing from DB, performing CIS search...
            * */
            else if((numOfRecordFetched == 0) && (searchField.equals(ClientCriteriaModel.SEARCH_TYPE.CIN) || searchField.equals(ClientCriteriaModel.SEARCH_TYPE.ACCOUNT)))
            {
                //we're unable to find anything in RET DB, seeking CIS to see if any luck?
                //initialize search result
                ClientModel cisCM = null;
                if(searchField.equals(ClientCriteriaModel.SEARCH_TYPE.CIN))
                {
                    logger.info("Unable to locate in DB, performing CIS search for CIN: " + keyStr);
                    cisCM = cisDaoImpl.getClients(Consts.CIS_BY_CIN, keyStr);
                }
                else if(searchField.equals(ClientCriteriaModel.SEARCH_TYPE.ACCOUNT))
                {
                    logger.info("Unable to locate in DB, performing CIS search for Account No: " + keyStr);
                    cisCM = cisDaoImpl.getClients(Consts.CIS_BY_ACC, keyStr);
                }
                if(cisCM != null && (cisCM.getCin() != null || cisCM.getAccountNumber() != null))
                {
                    logger.info("CIS: " + cisCM.getCin() + " | " + cisCM.getBranch() + " | " + cisCM.getClientName());
                    if(branches.contains(cisCM.getBranch().trim())) {
                        logger.info("RET user is entitled for " + cisCM.getBranch());
                        responseData.put("TOTAL_RECORD", 1);
                        responseData.put("NO_OF_RECORD", 1);
                        responseData.put("DATA", cisCM);
                    }
                    else
                    {
                        logger.info("Sorry, current RET user is not allowed to search this client");
                    }
                }
            }
            return responseData;
        } catch (Exception ex) {
            logger.error("Error getting branch list for RET user: " + clientCriteriaModel.getRETUserName());
            logger.error(ex.getStackTrace().toString());
            throw new FindException(ex);
        }
    }

    private String getMaterializedViewName(final String searchType)
    {
        String viewName = "";
        if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.CIN))
            viewName = "VW_DBS_SGCUSTOMER_BYCIN";
        else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.NAME))
            viewName = "VW_DBS_SGCUSTOMER_BYNAME";
        else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.MNEMONIC))
            viewName = "VW_DBS_SGCUSTOMER_BYMNEMONIC";
        else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.ACCOUNT))
            viewName = "VW_DBS_SGCUSTOMER_BYACC";
        else
            logger.error("Unknown search type: " + searchType);

        return viewName;
    }

    private String[] buildSQLWhereClause(final String searchType, final String searchStr, final String tierFilter) {
        String sqlWhere = "";
        String sqlOrder = "";
        if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.CIN)) {
            sqlWhere = " WHERE UPPER(cu.CIN) LIKE UPPER('" + searchStr + "')" + tierFilter;
            sqlOrder = " ORDER BY upper(A_.CIN) ";
        } else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.NAME)) {
            sqlWhere = " WHERE UPPER(cu.CUSTOMER_NAME) LIKE UPPER('" + searchStr + "')" + tierFilter;
            sqlOrder = " ORDER BY upper(A_.CUSTOMER_NAME) ";
        } else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.MNEMONIC)) {
            sqlWhere = " WHERE UPPER(cu.MNEMONIC) LIKE UPPER('" + searchStr + "')" + tierFilter;
            sqlOrder = " ORDER BY upper(A_.MNEMONIC) ";
        } else if (searchType.equals(ClientCriteriaModel.SEARCH_TYPE.ACCOUNT)) {
            sqlWhere = " WHERE UPPER(cu.ACC_NO_KIF) LIKE UPPER('" + searchStr + "')" + tierFilter;
            sqlOrder = " ORDER BY upper(A_.ACC_NO_KIF) ";
        }
        return new String[]{sqlWhere, sqlOrder};
    }

    private String buildSearchStrPattern(final String searchValue, final String matchType) {
        if (matchType.equals(ClientCriteriaModel.MATCH_TYPE.STARTS_WITH)) {
            return searchValue + "%";
        } else if (matchType.equals(ClientCriteriaModel.MATCH_TYPE.CONTAINS)) {
            return "%" + searchValue + "%";
        } else if (matchType.equals(ClientCriteriaModel.MATCH_TYPE.ENDS_WITH)) {
            return "%" + searchValue;
        } else {
            return searchValue;
        }
    }

    private String buildTierFilterString(final List<String> branches) {
        return " AND (cu.BRANCH IN (\'" + StringUtils.join(branches, ",").replaceAll(",", "\',\'") + "\')) ";
    }

    private String buildCountStatement(final String sqlWhere)
    {
        /*
        String sql = "SELECT COUNT(1) AS COUNTER FROM DBS_SGCUSTOMER cu LEFT JOIN DBS_SGCUSTBRANCHTAG bt ON"
                + " bt.CIN = cu.CIN AND bt.CIN_SUFFIX = cu.CIN_SUFFIX "
                + sqlWhere
                + " AND cu.ACCOUNT_STATUS='0' ";
        */

        String sql = "SELECT count(1)*100  estimated_count "
                    + " FROM DBS_SGCUSTOMER sample(1) cu "
                    + sqlWhere
                    + " AND ACCOUNT_STATUS='0' ";

        return sql;
    }

    private String buildSql(final String sqlWhere, final String sqlOrder, final Integer startRow, final Integer numRow, final String searchField) {

        String oracleHint = " /*+ FIRST_ROWS (50)*/ ";

        /*
        * Fuzzy search by DealOnline: it returns a certain number of records without sorting
        * */
        String sql = "SELECT " +
                "   A_.CIN ||'-'|| A_.CIN_SUFFIX AS \"cin\" " +
                " , A_.CUSTOMER_NAME AS \"clientName\" " +
                " , A_.MNEMONIC AS \"mnemonic\" " +
                " , A_.ACC_NO_KIF AS \"accountNumber\" " +
                " , A_.BRANCH AS \"branch\" " +
                " , A_.BRANCH_TIER AS \"branchTier\" " +
                " , CASE " +
                "      WHEN A_.DUMMY_USER IS NULL THEN '' " +
                "      ELSE 'YES' " +
                "   END AS \"webClient\" " +
                " , A_.DUMMY_USER \"dummyUser\" " +
                "FROM " +
                "( " +
                "   SELECT " + oracleHint +
                "     CU.CIN " +
                "    , CU.CIN_SUFFIX " +
                "    , CU.CUSTOMER_NAME " +
                "    , CU.MNEMONIC " +
                "    , CU.ACC_NO_KIF " +
                "    , CU.BRANCH " +
                "    , CU.DUMMY_USER " +
                "    , CASE " +
                "         WHEN LENGTH(BT.BRANCH_TIER) > 0 THEN BT.BRANCH_TIER " +
                "         ELSE CU.BRANCH_TIER " +
                "      END AS BRANCH_TIER " +
                "   FROM " +
                getMaterializedViewName(searchField) + " CU " +
                //"      DBS_SGCUSTOMER CU " +
                "   LEFT OUTER JOIN DBS_SGCUSTBRANCHTAG BT " +
                "   ON " +
                "      TRIM(BT.CIN) = TRIM(CU.CIN) " +
                "      AND TRIM(BT.CIN_SUFFIX) = TRIM(CU.CIN_SUFFIX) " + sqlWhere + " " +
                //"      AND CU.ACCOUNT_STATUS = '0' " +
                " AND ROWNUM >= " + startRow + " " +
                " AND ROWNUM <= " + (startRow + numRow - 1) + " " +
                " ) " +
                "A_ "
                // + sqlOrder
                ;
        return sql;
    }
}