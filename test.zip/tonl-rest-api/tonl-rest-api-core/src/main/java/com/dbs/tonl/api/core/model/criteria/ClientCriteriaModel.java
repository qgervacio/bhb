/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.model.criteria;

import com.dbs.tonl.api.core.model.AbstractModel;

/**
 * Client criteria model.
 *
 * @author quirinogervacio on 9/1/15.
 */
public class ClientCriteriaModel extends AbstractModel {

    public static interface SEARCH_TYPE {
        public static final String CIN      = "0";
        public static final String NAME     = "1";
        public static final String MNEMONIC = "2";
        public static final String ACCOUNT  = "3";
    }

    public static interface MATCH_TYPE {
        public static final String STARTS_WITH = "0";
        public static final String CONTAINS    = "1";
        public static final String ENDS_WITH   = "2";
        public static final String EXACT_MATCH = "3";
    }

    private String matchType;
    private String searchField;
    private String searchValue;
    private String RETUserName;
    private int    startRow;
    private int    numRow;
    //root group is the top-most group when we traverses through to find parent, parent's parent etc...
    private String rootGroup;

    public String getMatchType() {
        return matchType;
    }

    public void setMatchType(final String matchType) {
        this.matchType = matchType;
    }

    public String getSearchField() {
        return searchField;
    }

    public void setSearchField(final String searchField) {
        this.searchField = searchField;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(final String searchValue) {
        this.searchValue = searchValue;
    }

    public String getRETUserName() {
        return RETUserName;
    }

    public void setRETUserName(final String RETUserName) {
        this.RETUserName = RETUserName;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(final int startRow) {
        this.startRow = startRow;
    }

    public int getNumRow() {
        return numRow;
    }

    public void setNumRow(final int numRow) {
        this.numRow = numRow;
    }

    public String getRootGroup() {
        return rootGroup;
    }

    public void setRootGroup(final String rootGroup) {
        this.rootGroup = rootGroup;
    }
}