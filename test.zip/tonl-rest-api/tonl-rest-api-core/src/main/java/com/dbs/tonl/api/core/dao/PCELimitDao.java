package com.dbs.tonl.api.core.dao;


import com.dbs.tonl.api.core.model.PCELimitModel;

import java.util.List;

/**
 * Created by xueliang on 18/05/2015.
 */

public interface PCELimitDao {

    public List<PCELimitModel> previewPCELimit (String CIN, String account);
}
