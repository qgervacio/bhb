package com.dbs.tonl.api.core.dao.impl;

/**
 * Created by xueliang on 11/03/2015.
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class MQHandler implements ExceptionListener {

    @Autowired
    private Environment env;

    private static final Logger logger = LoggerFactory.getLogger(MQHandler.class);

    private String mqQueueManager;
    private String mqQueueIn;
    private String mqQueueOut;
    private String mqContextFactory;
    private String mqURLProvider;
    private String mqSecurityAuth;
    private QueueConnection connection;
    private QueueSessionPool queueSessionPool;
    private Queue sendQueue;
    private Queue receiveQueue;
    private int maxSessionIdolTime = 600;
    private static MQHandler mqHandler;

    public static MQHandler getInstance() throws JMSException, NamingException {
        if (mqHandler == null) {
            mqHandler = new MQHandler();
            mqHandler.init();
        }
        return mqHandler;
    }

    private void init() throws JMSException, NamingException {
        //to be changed: get from Environment
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("app.properties");

        Properties pp = new Properties();
        try {
            pp.load(in);

        }
        catch(FileNotFoundException e)
        {
            logger.error("Unable to find file app.properties");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally
        {
            if(in != null)
            {
                try {
                    in.close();
                }
                catch(Exception e)
                {
                    logger.error("Unable to close file: ", e);
                }

            }
        }



        this.mqContextFactory = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqContextFactory");
        this.mqURLProvider = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqURLProvider");
        this.mqSecurityAuth = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqSecurityAuth");
        this.mqQueueManager = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqQueueManager");
        this.mqQueueIn = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqQueueIn");
        this.mqQueueOut = pp.getProperty("com.dbs.retsg.custom.MQHandler.mqQueueOut");
        String str = pp.getProperty("com.dbs.retsg.custom.MQHandler.maxSessionIdolTime");
        if (str != null)
            this.maxSessionIdolTime = Integer.parseInt(str);
        logger.info(getConnectionInfo());
        connect();
        logger.info("MQ connected!");
        this.queueSessionPool = new QueueSessionPool(this.maxSessionIdolTime);
        logger.info("MQHandler Initialized!");
    }

    private String getConnectionInfo() {
        StringBuilder localStringBuilder = new StringBuilder();
        String str = System.getProperty("line.separator");
        localStringBuilder.append("MQ info:").append(str);

        localStringBuilder.append("  queue manager - '")
                .append(this.mqQueueManager).append("'").append(str);

        localStringBuilder.append("  queue in      - '").append(this.mqQueueIn)
                .append("'").append(str);
        localStringBuilder.append("  queue out     - '")
                .append(this.mqQueueOut).append("'").append(str);
        return localStringBuilder.toString();
    }

    private void connect() throws JMSException, NamingException {
        Hashtable <String, String>env=new Hashtable <String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, mqContextFactory);
        env.put(Context.PROVIDER_URL, mqURLProvider);
        env.put(Context.SECURITY_AUTHENTICATION,mqSecurityAuth);
        logger.info("intialContext...");
        Context ctx=new InitialContext(env);
        logger.info("lookup queue factory");
        QueueConnectionFactory fac=(QueueConnectionFactory)ctx.lookup(mqQueueManager);
        logger.info("lookup queue");
        sendQueue = (Queue)ctx.lookup(mqQueueIn);
        receiveQueue = (Queue)ctx.lookup(mqQueueOut);
        logger.info("create connection");
        connection = fac.createQueueConnection();
        connection.setExceptionListener(this);
        logger.info("starting connection");
        connection.start();

        logger.info("Message Queue Connected!");
    }

    public void close() throws JMSException {
        logger.info("closing Queue sessions...");
        if (this.queueSessionPool != null)
            this.queueSessionPool.close();
        logger.info("Queue Sessions closed successfully!");
        logger.info("closing Queue connecton...");
        if (this.connection != null)
            this.connection.close();
        logger.info("QueueConnection closed successfully!");
    }

    public String sendAndReceive(String paramString, int paramInt)
            throws JMSException {
        if (logger.isDebugEnabled()) {
            logger.debug("MQHandler.sendAndReceive() is called...");
        }

        String str1 = null;
        QueueSession localQueueSession = null;
        QueueSender localQueueSender = null;
        QueueReceiver localQueueReceiver = null;
        try {
            if (logger.isDebugEnabled())
                logger.debug("total queue session "
                        + this.queueSessionPool.getSessionCounter()
                        + ", unlocked Session "
                        + this.queueSessionPool.getUnlockedSessionCounter());
            localQueueSession = this.queueSessionPool.checkOut();
            localQueueSender = localQueueSession.createSender(this.sendQueue);
            TextMessage localTextMessage = localQueueSession
                    .createTextMessage();
            localTextMessage.setText(paramString);
            localTextMessage.setJMSReplyTo(this.receiveQueue);
            logger.info(paramString);
            if (logger.isDebugEnabled())
                logger.debug("Sending IP Request...");
            localQueueSender.setDeliveryMode(1);
            localQueueSender.send(localTextMessage);
            logger.info(localQueueSender.getClass().getName());

            String str2 = localTextMessage.getJMSMessageID();
            logger.info("MessageID: " + str2);
            String str3 = "JMSCorrelationID='" + str2 + "'";
            localQueueReceiver = localQueueSession.createReceiver(
                    this.receiveQueue, str3);
            if (logger.isDebugEnabled()) {
                logger.debug("Receiving IP Response...");
            }
            Message localMessage = localQueueReceiver.receive(paramInt);
            if (localMessage == null) {
                if (logger.isDebugEnabled())
                    logger.debug("Timeout! No response received from MQ! timeout="
                            + paramInt);
                throw new JMSException("Timeout[" + paramInt
                        + "]! No response received from MQ");
            }
            str1 = ((TextMessage) localMessage).getText();
            logger.info(str1);
        } catch (JMSException localJMSException3) {
            if (localQueueSender != null)
                try {
                    localQueueSender.close();
                    localQueueSender = null;
                } catch (JMSException localJMSException4) {
                    logger.error("fail to close sender", localJMSException4);
                }
            if (localQueueReceiver != null)
                try {
                    localQueueReceiver.close();
                    localQueueReceiver = null;
                } catch (JMSException localJMSException5) {
                    logger.error("fail to close receiver", localJMSException5);
                }
            if (localQueueSession != null) {
                this.queueSessionPool.removeLocked(localQueueSession);
                this.queueSessionPool.expire(localQueueSession);
                localQueueSession = null;
            }
            throw localJMSException3;
        } finally {
            if (localQueueSender != null)
                try {
                    localQueueSender.close();
                } catch (JMSException localJMSException6) {
                    logger.error("fail to close sender", localJMSException6);
                }
            if (localQueueReceiver != null)
                try {
                    localQueueReceiver.close();
                } catch (JMSException localJMSException7) {
                    logger.error("fail to close receiver", localJMSException7);
                }
            if (localQueueSession != null)
                this.queueSessionPool.checkIn(localQueueSession);
        }
        return str1;
    }

    public void onException(JMSException paramJMSException) {
        logger.error("Exception catched for the MQ Connection: ",
                paramJMSException);
    }

    public int getLockedSessionSize() {
        return this.queueSessionPool.getLockedSessionCounter();
    }

    public int getUnlockedSessionSize() {
        return this.queueSessionPool.getUnlockedSessionCounter();
    }

    private class QueueSessionPool {
        private long maxMQSessionIdolTime;
        private Hashtable<QueueSession, Long> locked;
        private Hashtable<QueueSession, Long> unlocked;

        private QueueSessionPool(int maxSessionIdolTime) {
            this.maxMQSessionIdolTime = ((long) maxSessionIdolTime) * 1000;
            locked = new Hashtable<QueueSession, Long>();
            unlocked = new Hashtable<QueueSession, Long>();
        }

        private QueueSession create() throws JMSException {
            return MQHandler.this.connection.createQueueSession(false, 1);
        }

        private boolean validate(QueueSession paramQueueSession, Long paramLong) {
            if (paramQueueSession == null) {
                return false;
            }
            if (paramLong == null) {
                return false;
            }
            if (System.currentTimeMillis() - paramLong.longValue() > this.maxMQSessionIdolTime) {
                MQHandler.logger.debug("one idol session cleaned up");
                return false;
            }
            return true;
        }

        private void expire(QueueSession paramQueueSession) {
            if (paramQueueSession != null)
                try {
                    paramQueueSession.close();
                } catch (JMSException localJMSException) {
                    MQHandler.logger.error("fail to close jms session",
                            localJMSException);
                }
        }

        public synchronized QueueSession checkOut() {
            long l = System.currentTimeMillis();
            QueueSession localQueueSession = null;
            if (this.unlocked.size() > 0) {
                Enumeration localEnumeration = this.unlocked.keys();
                while (localEnumeration.hasMoreElements()) {
                    localQueueSession = (QueueSession) localEnumeration
                            .nextElement();
                    if (validate(localQueueSession,
                            (Long) this.unlocked.get(localQueueSession))) {
                        this.unlocked.remove(localQueueSession);
                        this.locked.put(localQueueSession, Long.valueOf(l));
                        return localQueueSession;
                    }

                    this.unlocked.remove(localQueueSession);
                    expire(localQueueSession);
                    localQueueSession = null;
                }
            }

            try {
                localQueueSession = create();
                this.locked.put(localQueueSession, Long.valueOf(l));
            } catch (JMSException localJMSException) {
                MQHandler.logger.error("fail to create new session",
                        localJMSException);
            }
            return localQueueSession;
        }

        public synchronized void checkIn(QueueSession paramQueueSession) {
            this.locked.remove(paramQueueSession);
            this.unlocked.put(paramQueueSession,
                    Long.valueOf(System.currentTimeMillis()));
        }

        private int getSessionCounter() {
            return this.locked.size() + this.unlocked.size();
        }

        private int getLockedSessionCounter() {
            return this.locked.size();
        }

        private int getUnlockedSessionCounter() {
            return this.unlocked.size();
        }

        private void removeLocked(QueueSession paramQueueSession) {
            this.locked.remove(paramQueueSession);
        }

        private void close() {
            Enumeration localEnumeration = this.unlocked.keys();
            while (localEnumeration.hasMoreElements()) {
                expire((QueueSession) localEnumeration.nextElement());
            }
            localEnumeration = this.locked.keys();
            while (localEnumeration.hasMoreElements())
                expire((QueueSession) localEnumeration.nextElement());
        }
    }
}
