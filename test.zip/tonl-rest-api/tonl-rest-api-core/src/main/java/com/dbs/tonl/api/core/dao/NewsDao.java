package com.dbs.tonl.api.core.dao;

import com.dbs.tonl.api.core.model.NewsModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;

import java.util.HashMap;
import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
public interface NewsDao {
    public List<NewsModel> getNews(final int numOfNews) throws FindException;
}
