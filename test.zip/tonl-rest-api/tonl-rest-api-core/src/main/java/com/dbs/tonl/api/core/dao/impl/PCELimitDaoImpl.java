package com.dbs.tonl.api.core.dao.impl;

import com.dbs.tonl.api.core.dao.PCELimitDao;
import com.dbs.tonl.api.core.model.PCELimitModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.naming.NamingException;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by xueliang on 18/05/2015.
 */
@Repository
public class PCELimitDaoImpl implements PCELimitDao{

    @Autowired
    private Environment env;

    private static final Logger logger = LoggerFactory.getLogger(PCELimitDaoImpl.class);

    private String reqMsgProp;
    private NumberFormat nf;
    private Pattern regexPattern;
    private Pattern errorPattern;
    private Pattern cinPattern;
    private Pattern ctpyPattern;
    private int lmt1;
    private int exp1;
    private int ccy;
    private String strTimeout;

    public static int count = 0;

    @PostConstruct
    protected void init()
    {
        reqMsgProp = env.getProperty("com.dbs.retsg.custom.RetrieveLimit.limitCheckRequest");
        nf = NumberFormat.getNumberInstance(Locale.US);

        regexPattern = Pattern.compile(env.getProperty("com.dbs.retsg.custom.RetrieveLimit.regexPatten"));
        errorPattern = Pattern.compile("<ems:StatusDesc>(.*)</ems:StatusDesc>");
        cinPattern = Pattern.compile("<ems:CISCIN>(.*)</ems:CISCIN>");
        ctpyPattern = Pattern.compile("<op:CounterpartyCode>(.*)</op:CounterpartyCode>");

        lmt1 = Integer.parseInt(env.getProperty("com.dbs.retsg.custom.RetrieveLimit.lmt1"));
        exp1 = Integer.parseInt(env.getProperty("com.dbs.retsg.custom.RetrieveLimit.exp1"));
        ccy = Integer.parseInt(env.getProperty("com.dbs.retsg.custom.RetrieveLimit.ccy"));
        strTimeout = env.getProperty("com.dbs.retsg.custom.RetrieveLimit.mqTimeout");
    }

    @Override
    public List<PCELimitModel> previewPCELimit(String cin, String account)
    {
        List<PCELimitModel> listOfPCELimits = new ArrayList<PCELimitModel>();
        listOfPCELimits.add(talkWithTZ(cin, account));
        return listOfPCELimits;
    }
    private PCELimitModel talkWithTZ(String cin, String account)
    {
        logger.debug("cin=" + cin + " , account=" + account);
        PCELimitModel pceLimitModel = new PCELimitModel();
        int timeout = 6000;
        if(strTimeout != null)
            timeout = Integer.parseInt(strTimeout);

        String[] cinSplitted = cin.split("-");
        Date localDate = new Date();
        String msgID = "retsg" + System.currentTimeMillis() + getCount();
        Object[] arrayOfObject = new Object[10];
        arrayOfObject[0] = msgID;
        arrayOfObject[1] = localDate;
        arrayOfObject[2] = localDate;
        arrayOfObject[3] = localDate;
        arrayOfObject[4] = account;
        arrayOfObject[5] = cinSplitted[0];
        arrayOfObject[6] = (cinSplitted.length > 1 ? cinSplitted[1] : "00");
        arrayOfObject[7] = localDate;
        arrayOfObject[8] = localDate;
        arrayOfObject[9] = localDate;

        String request2TZ = MessageFormat.format(reqMsgProp, arrayOfObject);
        String responseRecv = env.getProperty("com.dbs.retsg.custom.RetrieveLimit.fakeLimitCheckResponse");
        /*
        String responseRecv = "";
        try {
            logger.info("Sending to MQ: ");
            logger.info(request2TZ);
            responseRecv = MQHandler.getInstance().sendAndReceive(request2TZ, timeout);
            logger.info(responseRecv);
        } catch (JMSException localJMSException) {
            logger.error("MQ error ", localJMSException);
            pceLimitModel.setErrorCode("-1");
            pceLimitModel.setErrorDesc("MQ error");
            return pceLimitModel;

        } catch (NamingException localNamingException) {
            logger.error("MQ error", localNamingException);
            pceLimitModel.setErrorCode("-1");
            pceLimitModel.setErrorDesc("MQ error");
            return pceLimitModel;
        }
        */
        Matcher localMatcher = regexPattern.matcher(responseRecv);
        if (localMatcher.find()) {
            logger.debug(localMatcher.group(0));
            long l1 = Integer.parseInt(localMatcher.group(lmt1).trim());
            long l2 = Integer.parseInt(localMatcher.group(exp1).trim());
            String inCCY = localMatcher.group(ccy).trim();
            logger.info(inCCY + " " + nf.format(l1 - l2));

            localMatcher = cinPattern.matcher(responseRecv);
            if(localMatcher.find())
            {
                logger.debug("CIN = " + localMatcher.group(0) + " - " + localMatcher.group(1));
                pceLimitModel.setCin(localMatcher.group(1));
            }
            localMatcher = ctpyPattern.matcher(responseRecv);
            if(localMatcher.find())
            {
                logger.debug("CTPY = " + localMatcher.group(0) + " - " + localMatcher.group(1));
                pceLimitModel.setCtpy(localMatcher.group(1));
            }

            pceLimitModel.setStatus("0");
            pceLimitModel.setLimit(inCCY + " " + nf.format(l1 - l2));
        }
        else {
            localMatcher = errorPattern.matcher(responseRecv);
            logger.debug("Matching status info:");
            if (localMatcher.find()) {
                logger.debug(localMatcher.group(0));
                pceLimitModel.setStatus("-2");
                pceLimitModel.setMsg(localMatcher.group(1));
            }
        }
        return pceLimitModel;
    }

    public static synchronized int getCount() {
        if (count > 98) count = 0;
        return count++;
    }
}
