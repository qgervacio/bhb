package com.dbs.tonl.api.core.service;

/**
 * Created by xueliang on 11/03/2015.
 */

import com.dbs.tonl.api.core.dao.CISDao;
import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.springframework.stereotype.Service;


import java.util.HashMap;

@Service
public interface CISOnlineService extends CISDao {
    @Override
    public ClientModel getClients(final int CINorACC, final String keyString) throws ServiceException;
}
