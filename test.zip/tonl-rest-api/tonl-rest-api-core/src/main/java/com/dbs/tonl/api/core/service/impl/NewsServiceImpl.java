package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.dao.NewsDao;
import com.dbs.tonl.api.core.model.NewsModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import com.dbs.tonl.api.core.service.NewsService;
import com.dbs.tonl.api.core.service.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
@Service
public class NewsServiceImpl implements NewsService{
    @Autowired
    private NewsDao newsDao;

    @Override
    public List<NewsModel> getNews(final int numOfNews) throws ServiceException {
        try {
            return this.newsDao.getNews(numOfNews);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
}
