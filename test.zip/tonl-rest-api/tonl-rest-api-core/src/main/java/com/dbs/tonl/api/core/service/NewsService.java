package com.dbs.tonl.api.core.service;

import com.dbs.tonl.api.core.dao.NewsDao;
import com.dbs.tonl.api.core.model.NewsModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
@Service
public interface NewsService extends NewsDao{
    @Override
    public List<NewsModel> getNews(final int numOfNews) throws ServiceException;

}
