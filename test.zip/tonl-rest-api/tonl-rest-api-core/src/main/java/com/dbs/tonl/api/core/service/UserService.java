/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.service;

import com.dbs.tonl.api.core.dao.UserDao;
import com.dbs.tonl.api.core.model.UserModel;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * User service.
 *
 * @author quirinogervacio on 6/1/15.
 */
@Service
public interface UserService extends UserDao {

    @Override
    public UserModel getUser(final String username) throws ServiceException;

    @Override
    public List<UserModel> getUsersByGroupName(final String groupName) throws ServiceException;
}