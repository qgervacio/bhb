/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.BranchDao;
import com.dbs.tonl.api.core.service.BranchService;
import com.dbs.tonl.api.core.service.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Branch service implementation.
 *
 * @author quirinogervacio on 12/1/15.
 */
@Service
class BranchServiceImpl implements BranchService {

    @Autowired
    private BranchDao branchDao;

    @Override
    public List<String> getBranchesFromUserInGroup(final String username, final String rootGroup) throws ServiceException {
        try {
            return this.branchDao.getBranchesFromUserInGroup(username, rootGroup);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
}