/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.service;

import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * Client service.
 *
 * @author quirinogervacio on 9/1/15.
 */
@Service
public interface ClientService extends ClientDao {

    @Override
    public HashMap getClients(final ClientCriteriaModel clientCriteriaModel) throws ServiceException;
}