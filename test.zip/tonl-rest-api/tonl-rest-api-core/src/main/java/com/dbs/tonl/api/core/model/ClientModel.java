/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Client model.
 *
 * @author quirinogervacio on 12/1/15.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ClientModel extends AbstractModel {
    private String cin;
    private String clientName;
    private String mnemonic;
    private String accountNumber;
    private String branch;
    private String branchTier;
    private String webClient;
    private String dummyUser;

    public String getCin() {
        return cin;
    }

    public void setCin(final String cin) {
        this.cin = cin;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(final String clientName) {
        this.clientName = clientName;
    }

    public String getMnemonic() {
        return mnemonic;
    }

    public void setMnemonic(final String mnemonic) {
        this.mnemonic = mnemonic;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(final String branch) {
        this.branch = branch;
    }

    public String getBranchTier() {
        return branchTier;
    }

    public void setBranchTier(final String branchTier) {
        this.branchTier = branchTier;
    }

    public String getWebClient() {
        return webClient;
    }

    public void setWebClient(final String webClient) {
        this.webClient = webClient;
    }

    public String getDummyUser() {
        return dummyUser;
    }

    public void setDummyUser(final String dummyUser) {
        this.dummyUser = dummyUser;
    }
}