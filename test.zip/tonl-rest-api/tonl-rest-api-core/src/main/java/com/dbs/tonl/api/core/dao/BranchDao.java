/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao;

import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Branch DAO.
 *
 * @author quirinogervacio on 12/1/15.
 */
@Repository
public interface BranchDao {

    public List<String> getBranchesFromUserInGroup(final String username, final String rootGroup) throws FindException;
}