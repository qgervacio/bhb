package com.dbs.tonl.api.core.service;

import com.dbs.tonl.api.core.dao.PCELimitDao;
import com.dbs.tonl.api.core.model.PCELimitModel;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by xueliang on 18/05/2015.
 */
@Service
public interface PCELimitService extends PCELimitDao{
    @Override
    public List<PCELimitModel> previewPCELimit(final String CIN, final String account) throws ServiceException;
}
