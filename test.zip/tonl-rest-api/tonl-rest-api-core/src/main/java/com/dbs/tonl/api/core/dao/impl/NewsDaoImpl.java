package com.dbs.tonl.api.core.dao.impl;

import com.dbs.tonl.api.core.dao.FindException;
import com.dbs.tonl.api.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import com.dbs.tonl.api.core.dao.NewsDao;

import java.util.List;

/**
 * Created by xueliang on 25/02/2015.
 */
@Repository
public class NewsDaoImpl implements NewsDao{
    private static final Logger logger = LoggerFactory.getLogger(ClientDaoImpl.class);

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<NewsModel> getNews(final int numOfNews) throws FindException
    {

        String sql = "" +
                "SELECT\n" +
                "   TITLE  AS \"title\"\n" +
                " , DISTRIBUTOR AS \"distributor\"\n" +
                " , BODY     AS \"body\"\n" +
                " , LOCATIONS      AS \"location\"\n" +
                " , TOPICS  AS \"topic\"\n" +
                " , LANGUAGE  AS \"language\"\n" +
                " , PUBLICATION_DATETIME  AS \"publication_datetime\"\n" +
                "FROM\n" +
                "(select * from RET_NEWS2_FEED order by PUBLICATION_DATETIME desc)" +
                "WHERE ROWNUM <= :rowNumber";

        MapSqlParameterSource namedParams = new MapSqlParameterSource();
        namedParams.addValue("rowNumber", numOfNews);

        return this.namedParameterJdbcTemplate.query(sql, namedParams, new BeanPropertyRowMapper<NewsModel>(NewsModel.class));

    }
}
