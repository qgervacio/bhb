/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao;

import com.dbs.tonl.api.core.model.UserModel;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User DAO.
 *
 * @author quirinogervacio on 26/12/14.
 */
@Repository
public interface UserDao {

    public UserModel getUser(final String username) throws FindException;

    public List<UserModel> getUsersByGroupName(final String groupName) throws FindException;
}