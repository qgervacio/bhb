/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.dao.impl;

import com.dbs.tonl.api.common.util.TestUtil;
import com.dbs.tonl.api.core.dao.BranchDao;
import com.dbs.tonl.api.core.dao.FindException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Branch DAO implementation.
 *
 * @author quirinogervacio on 12/1/15.
 */
@Repository
class BranchDaoImpl implements BranchDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /*
    *   check if this is such a user in RET??
    * */
    public Boolean validateRETUser(final String username) throws FindException
    {
        String sql = "select username from users where username = ?";
        String RETUser = "";
        try {
            RETUser = jdbcTemplate.queryForObject(sql, new Object[]{username}, String.class);
        }
        catch(Exception ex)
        {
            return false;
        }

        return true;
    }

    @Override
    public List<String> getBranchesFromUserInGroup(final String username, final String rootGroup) throws FindException {
        TestUtil.test(NullPointerException.class, username != null, "Parameter \"username\" must not be null");
        TestUtil.test(IllegalArgumentException.class, username.length() > 0, "Parameter \"username\" must not be an empty String");
        TestUtil.test(NullPointerException.class, rootGroup != null, "Parameter \"rootGroup\" must not be null");
        TestUtil.test(IllegalArgumentException.class, rootGroup.length() > 0, "Parameter \"rootGroup\" must not be an empty String");
        String sql = "" +
                "SELECT DISTINCT " +
                "   USERNAME " +
                "FROM " +
                "   USERSET_USERS " +
                "WHERE " +
                "   USERSETNAME IN " +
                "   (SELECT " +
                "      USERSETNAME " +
                "   FROM " +
                "      GROUP_USERSETS " +
                "   WHERE " +
                "      GROUPNAME IN " +
                "      (SELECT " +
                "         TRIM(REGEXP_SUBSTR(G.PATH, '[^/]+', 1, LEVEL)) GROUP_NAME " +
                "      FROM " +
                "         DUAL D " +
                "       ,(SELECT " +
                "            U.USERNAME " +
                "          , G.GROUPNAME " +
                "          , G.PATH " +
                "         FROM " +
                "            USERS U " +
                "          ,(SELECT " +
                "               GROUPNAME " +
                "             , PATH " +
                "            FROM " +
                "               (SELECT " +
                "                  GROUPNAME " +
                "                , SYS_CONNECT_BY_PATH(GROUPNAME, '/') AS PATH " +
                "               FROM " +
                "                  GROUPS " +
                "                  CONNECT BY PRIOR GROUPNAME = PARENTGROUP " +
                "               ) " +
                "            WHERE " +
                "               REGEXP_LIKE(PATH, '/" + rootGroup.toUpperCase() + "') " +
                "            ) G " +
                "         WHERE " +
                "            U.GROUPNAME = G.GROUPNAME " +
                "            AND UPPER(U.USERNAME) = '" + username.toUpperCase() + "' " +
                "         ) G " +
                "         CONNECT BY LEVEL <= REGEXP_COUNT(G.PATH, '/') " +
                "      ) " +
                "   ) " +
                "UNION " +
                "   (SELECT DISTINCT " +
                "      USERNAME " +
                "   FROM " +
                "      USERSET_USERS " +
                "   WHERE " +
                "      USERSETNAME IN " +
                "      (SELECT " +
                "         USERSETNAME " +
                "      FROM " +
                "         USER_USERSETS " +
                "      WHERE " +
                "         UPPER(USERNAME) = '" + username.toUpperCase() + "' " +
                "      ) " +
                "   )";

        //return
        try {
            return this.jdbcTemplate.queryForList(sql, String.class);
        } catch (Exception ex) {
            throw new FindException(ex);
        }
    }
}