package com.dbs.tonl.api.core.dao;

/**
 * Created by xueliang on 13/01/2015.
 */

public class InvalidParameterException extends DaoException
{
    private String invalidParameter;


    public InvalidParameterException(final String message) {
        super(message);
        invalidParameter = message;
    }

    public String getErrMessage()
    {
        return invalidParameter;
    }

}