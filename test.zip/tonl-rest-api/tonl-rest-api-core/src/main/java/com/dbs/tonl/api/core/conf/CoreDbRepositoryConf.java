/*
 * All rights reserved. No part of this program may be reproduced in any form outside the DBS Group
 * without an authorized release. Copyright 2015.
 */

package com.dbs.tonl.api.core.conf;

import com.dbs.ret.crypto.Decryptor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import javax.sql.DataSource;
import org.apache.tomcat.dbcp.dbcp.BasicDataSource;

/**
 * All database related configuration.
 *
 * @author quirinogervacio on 26/12/14.
 */
@Configuration
class CoreDbRepositoryConf {

    @Autowired
    private Environment env;

    /**
     * Build data source.
     *
     * @return the data source
     */

    @Bean
    protected DataSource  dataSource() {

        BasicDataSource ds = new org.apache.tomcat.dbcp.dbcp.BasicDataSource();

        ds.setDriverClassName(this.env.getProperty("db.driverClassName"));
        ds.setUrl(this.env.getProperty("db.url"));

        // username
        final String username = this.env.getProperty("db.username");
        ds.setUsername(username);

        // use crypto if null. throw if null
        String password = StringUtils.stripToNull(this.env.getProperty("db.password"));
        password = password == null ? StringUtils.stripToNull(Decryptor.getDecryptedPassword(Decryptor.TYPE_DB, username)) : password;
        if (password == null) {
            throw new NullPointerException("Database password is null.");
        }
        ds.setPassword(password);

        //connection pool setting
        ds.setInitialSize(Integer.parseInt(env.getProperty("db.datasource.initialSize")));
        ds.setMaxActive(Integer.parseInt(env.getProperty("db.datasource.maxActive")));
        ds.setMaxIdle(Integer.parseInt(env.getProperty("db.datasource.maxIdle")));
        ds.setTestOnBorrow(Boolean.parseBoolean(env.getProperty("db.datasource.testOnBorrow")));
        ds.setValidationQuery(env.getProperty("db.datasource.validationQuery").trim());

        // return
        return ds;
    }

    /*
    @Bean
    protected DriverManagerDataSource dataSource() {
        final DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName(this.env.getProperty("db.driverClassName"));
        ds.setUrl(this.env.getProperty("db.url"));

        // username
        final String username = this.env.getProperty("db.username");
        ds.setUsername(username);

        // use crypto if null. throw if null
        String password = StringUtils.stripToNull(this.env.getProperty("db.password"));
        password = password == null ? StringUtils.stripToNull(Decryptor.getDecryptedPassword(Decryptor.TYPE_DB, username)) : password;
        if (password == null) {
            throw new NullPointerException("Database password is null.");
        }
        ds.setPassword(password);

        // return
        return ds;
    }
    */

    /**
     * Shared JDBC template.
     *
     * @return the jdbc
     */
    @Bean
    protected NamedParameterJdbcTemplate namedParameterJdbcTemplate() {
        return new NamedParameterJdbcTemplate(this.dataSource());
    }

    /**
     * Shared JDBC template.
     *
     * @return the jdbc
     */
    @Bean
    protected JdbcTemplate jdbcTemplate() {
        return new JdbcTemplate(this.dataSource());
    }
}