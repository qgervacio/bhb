package com.dbs.tonl.api.core.dao;

import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.HashMap;

/**
 * Created by xueliang on 11/03/2015.
 */
@Component
public interface CISDao {
    public ClientModel getClients(final int CinORAcc, final String keyword);
}
