package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.CISDao;
import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.service.CISOnlineService;
import com.dbs.tonl.api.core.service.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by xueliang on 11/03/2015.
 */
@Service
public class CISOnlineServiceImpl implements CISOnlineService {
    @Autowired
    private CISDao cisDao;

    @Override
    public ClientModel getClients(final int CINorACC, final String fullStr) throws ServiceException
    {
        try {
            return this.cisDao.getClients(CINorACC, fullStr);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
}
