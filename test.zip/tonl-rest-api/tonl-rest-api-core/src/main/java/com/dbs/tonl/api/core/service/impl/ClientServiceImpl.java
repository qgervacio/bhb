package com.dbs.tonl.api.core.service.impl;

import com.dbs.tonl.api.core.dao.ClientDao;
import com.dbs.tonl.api.core.model.ClientModel;
import com.dbs.tonl.api.core.model.criteria.ClientCriteriaModel;
import com.dbs.tonl.api.core.service.ClientService;
import com.dbs.tonl.api.core.service.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * Client service implementation.
 *
 * @author quirinogervacio on 9/1/15.
 */
@Service
class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientDao clientDao;

    @Override
    public HashMap getClients(final ClientCriteriaModel clientCriteriaModel) throws ServiceException {
        try {
            return this.clientDao.getClients(clientCriteriaModel);
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
}